import { FFmpeg } from "./vendor/ffmpeg-0.12.15/index.js";
import { CLIP_LENGTHS, CLIP_SECONDS } from "./clip-local.js";
import { CLIP_HOOK_SECONDS, CLIP_CTA_SECONDS, createClipTextLayer } from "./cover-local.js";

const CORE_BASE = "https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.10/dist/esm";
const MAX_INPUT_SIZE = 2 * 1024 * 1024 * 1024;
const MAX_MEMORY_COPY = 80 * 1024 * 1024;
const MAX_DURATION = 2 * 60 * 60;
const VIDEO_FILTER = [
  "[0:V:0]scale=ceil(iw*sar/2)*2:ih,setsar=1,split=2[b][f]",
  "[b]scale=270:480:force_original_aspect_ratio=increase:force_divisible_by=2," +
    "crop=270:480,boxblur=12:2,scale=1080:1920:flags=fast_bilinear,setsar=1[bg]",
  "[f]scale=1080:1920:force_original_aspect_ratio=decrease:force_divisible_by=2,setsar=1[fg]",
  "[bg][fg]overlay=(W-w)/2:(H-h)/2:shortest=1,format=yuv420p[v]",
].join(";");

function addTextLayers(baseFilters, baseStream, layers, seconds) {
  const inputFiles = [];
  const filters = [...baseFilters];
  let stream = baseStream;
  for (const [file, path, y, when] of [
    [layers?.hook, "/gancho.png", 176, "lt(t," + CLIP_HOOK_SECONDS + ")"],
    [layers?.cta, "/cta.png", 1260, "gte(t," + Math.max(0, seconds - CLIP_CTA_SECONDS) + ")"],
  ]) {
    if (!file) continue;
    inputFiles.push([path, file]);
    const index = inputFiles.length;
    const next = "[text" + index + "]";
    filters.push(stream + "[" + index + ":v]overlay=0:" + y + ":format=auto:enable='" + when + "'" + next);
    stream = next;
  }
  return { inputFiles, filter: filters.join(";"), stream };
}

function withDeadline(operation, milliseconds, message) {
  let timer;
  const deadline = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(message)), milliseconds);
  });
  return Promise.race([operation, deadline]).finally(() => clearTimeout(timer));
}

function timelineProgress(callback, duration, from, to, label) {
  let previous = -1;
  return ({ time }) => {
    if (!Number.isFinite(time)) return;
    const fraction = Math.min(1, Math.max(0, time / 1_000_000 / duration));
    const percent = Math.floor(fraction * 100);
    if (percent <= previous) return;
    previous = percent;
    callback(from + (to - from) * fraction, label);
  };
}

function readIntoMemory(file, signal) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    const abort = () => reader.abort();
    reader.onload = () => resolve(new Uint8Array(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.onabort = () => reject(signal?.reason ?? new DOMException("Operação cancelada.", "AbortError"));
    reader.onloadend = () => signal?.removeEventListener("abort", abort);
    signal?.throwIfAborted();
    reader.readAsArrayBuffer(file);
    signal?.addEventListener("abort", abort, { once: true });
  });
}

async function openVideo(file, onProgress, { signal, minimumDuration = CLIP_LENGTHS[0] }) {
  signal?.throwIfAborted();
  if (!(file instanceof Blob) || !file.size || file.size > MAX_INPUT_SIZE) {
    throw new Error("Selecione um vídeo de até 2 GB.");
  }
  if (typeof Worker !== "function" || typeof WebAssembly !== "object") {
    throw new Error("Este navegador não oferece suporte ao processamento de vídeo.");
  }

  const ffmpeg = new FFmpeg();
  const recentLogs = [];
  let closed = false;
  let busy = false;
  let source;
  let duration;
  let hasAudio;

  function close() {
    if (closed) return;
    closed = true;
    signal?.removeEventListener("abort", close);
    ffmpeg.terminate();
  }

  function checkOpen() {
    signal?.throwIfAborted();
    if (closed) throw new Error("O vídeo foi fechado. Abra o arquivo novamente.");
  }

  function requireSuccess(code, message) {
    if (code !== 0) {
      throw new Error(message, { cause: recentLogs.join("\n") });
    }
  }

  ffmpeg.on("log", ({ message }) => {
    if (recentLogs.length === 8) recentLogs.shift();
    recentLogs.push(message);
  });
  signal?.addEventListener("abort", close, { once: true });

  try {
    onProgress(0, "Carregando o editor de vídeo");
    checkOpen();
    await withDeadline(ffmpeg.load({
      coreURL: CORE_BASE + "/ffmpeg-core.js",
      wasmURL: CORE_BASE + "/ffmpeg-core.wasm",
    }), 120_000, "O editor de vídeo demorou a carregar. Verifique a conexão e tente de novo.");
    onProgress(0.15, "Lendo o vídeo");
    await ffmpeg.createDir("/input");
    const mounted = await ffmpeg.mount("WORKERFS", {
      blobs: [{ name: "origem", data: file }],
    }, "/input").catch(() => false);
    checkOpen();
    if (mounted) {
      source = "/input/origem";
    } else {
      if (file.size > MAX_MEMORY_COPY) {
        throw new Error("Este navegador não consegue abrir arquivos maiores que 80 MB sem copiá-los para a memória.");
      }
      source = "/origem";
      const bytes = await readIntoMemory(file, signal);
      checkOpen();
      await ffmpeg.writeFile(source, bytes);
    }

    await withDeadline(ffmpeg.ffprobe([
      "-v", "error", "-show_entries",
      "stream=codec_type,duration:stream_disposition=attached_pic:format=duration",
      "-of", "json", "-o", "/video.json", source,
    ]), 30_000, "O navegador demorou a ler o vídeo.");
    let metadata;
    try {
      // This WASM build can return -1 from ffprobe even after writing valid JSON.
      metadata = JSON.parse(await ffmpeg.readFile("/video.json", "utf8"));
    } catch (error) {
      throw new Error("Não foi possível abrir este arquivo de vídeo.", { cause: error });
    }
    const video = metadata.streams?.find(stream =>
      stream.codec_type === "video" && !stream.disposition?.attached_pic);
    if (!video) {
      throw new Error("Escolha um arquivo com uma faixa de vídeo.");
    }
    hasAudio = metadata.streams.some(stream => stream.codec_type === "audio");
    const lengths = [video.duration, metadata.format?.duration].map(Number)
      .filter(value => Number.isFinite(value) && value > 0);
    duration = Math.min(...lengths);
    if (!Number.isFinite(duration) || duration < minimumDuration || duration > MAX_DURATION) {
      throw new Error(minimumDuration
        ? "Escolha um vídeo com duração entre 30 segundos e 2 horas."
        : "Não foi possível determinar a duração do corte.");
    }
    await ffmpeg.deleteFile("/video.json");
    onProgress(1, "Vídeo pronto");
    checkOpen();
  } catch (error) {
    close();
    signal?.throwIfAborted();
    throw error instanceof Error ? error : new Error("Não foi possível carregar o editor de vídeo.", { cause: error });
  }

  async function exportMedia(args, {
    output, type, seconds, onUpdate, label, done, timeout, timeoutMessage, failure, inputFiles = [],
  }) {
    checkOpen();
    if (busy) throw new Error("Já há um trecho em processamento.");
    const update = timelineProgress(onUpdate, seconds, 0, 0.98, label);
    busy = true;
    recentLogs.length = 0;
    ffmpeg.on("progress", update);
    try {
      onUpdate(0, label);
      checkOpen();
      for (const [path, file] of inputFiles) {
        const bytes = new Uint8Array(await file.arrayBuffer());
        checkOpen();
        await ffmpeg.writeFile(path, bytes);
      }
      requireSuccess(await withDeadline(ffmpeg.exec([...args, output]), timeout, timeoutMessage), failure);
      const blob = new Blob([await ffmpeg.readFile(output)], { type });
      await ffmpeg.deleteFile(output);
      for (const [path] of inputFiles) await ffmpeg.deleteFile(path);
      onUpdate(1, done);
      checkOpen();
      return blob;
    } catch (error) {
      close();
      signal?.throwIfAborted();
      throw error instanceof Error ? error : new Error(failure, { cause: error });
    } finally {
      ffmpeg.off("progress", update);
      busy = false;
    }
  }

  return { duration, hasAudio, source, checkOpen, exportMedia, close };
}

export async function createVideoSession(file, onProgress = () => {}, { signal } = {}) {
  const { duration, hasAudio, source, checkOpen, exportMedia, close } = await openVideo(file, onProgress, { signal });

  async function extractAudio(start, length, onAudioProgress = () => {}) {
    checkOpen();
    if (!Number.isFinite(start) || !Number.isFinite(length) || start < 0
        || length <= 0 || start >= duration || start + length > duration + 0.000001) {
      throw new Error("O intervalo de áudio precisa estar dentro da duração do vídeo.");
    }
    const seconds = Math.min(length, duration - start);
    return exportMedia([
      "-threads", "1", "-ss", start.toFixed(6), "-i", source, "-t", seconds.toFixed(6),
      "-map", "0:a:0", "-vn", "-af", "apad", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le",
    ], {
      output: "/audio.wav", type: "audio/wav", seconds, onUpdate: onAudioProgress,
      label: "Extraindo áudio", done: "Áudio pronto",
      timeout: 120_000, timeoutMessage: "A extração do áudio excedeu o tempo disponível.",
      failure: "Não foi possível extrair o áudio deste vídeo.",
    });
  }

  async function render(startSeconds, onRenderProgress = () => {}, { seconds = CLIP_SECONDS, textLayers } = {}) {
    checkOpen();
    if (!CLIP_LENGTHS.includes(seconds)) throw new Error("Escolha cortes de 30 ou 65 segundos.");
    if (!Number.isFinite(startSeconds) || startSeconds < 0
        || startSeconds + seconds > duration + 0.000001) {
      throw new Error("O trecho escolhido precisa conter " + seconds + " segundos de vídeo.");
    }
    const start = Math.min(startSeconds, duration - seconds);
    const { inputFiles, filter, stream } = addTextLayers([VIDEO_FILTER], "[v]", textLayers, seconds);
    return exportMedia([
      "-threads", "1", "-ss", start.toFixed(6), "-i", source,
      ...inputFiles.flatMap(([path]) => ["-i", path]),
      "-t", String(seconds), "-filter_complex_threads", "1", "-filter_complex", filter,
      "-map", stream, "-map", "0:a:0?",
      "-c:v", "libx264", "-threads", "1", "-preset", "ultrafast", "-crf", "23",
      "-fpsmax", "30", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart",
    ], {
      output: "/corte.mp4", type: "video/mp4", seconds, onUpdate: onRenderProgress, inputFiles,
      label: "Exportando MP4", done: "MP4 pronto",
      timeout: 600_000, timeoutMessage: "A exportação excedeu o tempo disponível neste dispositivo.",
      failure: "Não foi possível exportar o corte deste vídeo.",
    });
  }

  return { duration, hasAudio, extractAudio, render, close };
}

export async function renderScreenText(videoBlob, { opening, ending, signal, onProgress = () => {} } = {}) {
  signal?.throwIfAborted();
  const firstText = String(opening ?? "").trim();
  const lastText = String(ending ?? "").trim();
  if (!firstText && !lastText) {
    onProgress(1, "MP4 pronto");
    return videoBlob;
  }

  onProgress(0, "Preparando o texto do corte");
  const [hook, cta] = await Promise.all([
    firstText ? createClipTextLayer(firstText, { signal }) : null,
    lastText ? createClipTextLayer(lastText, { action: true, signal }) : null,
  ]);
  const session = await openVideo(videoBlob, (fraction, label) => onProgress(.04 + fraction * (.18 - .04), label),
    { signal, minimumDuration: 0 });
  try {
    const { duration, source, exportMedia } = session;
    const { inputFiles, filter, stream } = addTextLayers([], "[0:V:0]", { hook, cta }, duration);
    return await exportMedia([
      "-threads", "1", "-i", source,
      ...inputFiles.flatMap(([path]) => ["-i", path]),
      "-filter_complex_threads", "1", "-filter_complex", filter,
      "-map", stream, "-map", "0:a:0?", "-c:a", "copy",
      "-c:v", "libx264", "-threads", "1", "-preset", "ultrafast", "-crf", "23",
      "-fps_mode", "passthrough", "-pix_fmt", "yuv420p", "-movflags", "+faststart",
    ], {
      output: "/corte.mp4", type: "video/mp4", seconds: duration, inputFiles,
      onUpdate: (fraction, label) => onProgress(.18 + fraction * .82, label),
      label: "Gravando texto no corte", done: "MP4 pronto",
      timeout: 600_000, timeoutMessage: "A exportação excedeu o tempo disponível neste dispositivo.",
      failure: "Não foi possível gravar o texto no corte.",
    });
  } finally {
    session.close();
  }
}
